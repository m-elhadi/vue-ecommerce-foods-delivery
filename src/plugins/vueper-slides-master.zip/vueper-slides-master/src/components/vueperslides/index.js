import VueperSlides from './vueperslides.vue'
import VueperSlide from './vueperslide.vue'

export { VueperSlides, VueperSlide }
